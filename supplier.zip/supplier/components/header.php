  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

      <a href="index.html" class="logo d-flex align-items-center me-auto">
        <img src="supplier/template/assets/img/logo.png" alt="">
        <h1 class="sitename">E-Inventory</h1>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="index.html#hero" class="active">Home</a></li>
          <li><a href="index.html#about">About</a></li>
          <li><a href="index.html#features">Dashboard</a></li>
          <li><a href="index.html#services">Penawaran Harga</a></li>
          <li><a href="index.html#pricing">Status PO</a></li>
          <li><a href="index.html#contact">Profile</a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

      <a class="btn-getstarted" href="index.html#about">Login</a>

    </div>
  </header>